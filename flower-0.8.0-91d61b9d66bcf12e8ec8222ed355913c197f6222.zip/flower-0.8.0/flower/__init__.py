from __future__ import absolute_import

VERSION = (0, 8, 0)
__version__ = '.'.join(map(str, VERSION)) + '-91d61b9d66bcf12e8ec8222ed355913c197f6222'

from .app import Flower  # noqa
